package project.personal.beans;

import java.io.Serializable;

public class DailyTrackerResponseBean implements Serializable{
	

	private static final long serialVersionUID = -130789081095662545L;

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
