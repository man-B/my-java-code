package project.personal.beans;

import java.io.Serializable;

public class DayTrackerRequestBean implements Serializable {

	private static final long serialVersionUID = -4795414022636659103L;
	private String activity;

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}
}
