package project.personal.beans;

import java.io.Serializable;

public class ResponseBean<T extends Serializable>  implements Serializable{

	private static final long serialVersionUID = -6270106225061483031L;
	
	String status;
	String statusMessage;
	T data;
	
	public ResponseBean(T data, String status, String statusMessage){
		this.data = data;
		this.status = status;
		this.statusMessage = statusMessage;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
}
