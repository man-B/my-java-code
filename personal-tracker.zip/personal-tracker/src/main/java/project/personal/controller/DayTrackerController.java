package project.personal.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import project.personal.beans.DailyTrackerResponseBean;
import project.personal.beans.DayTrackerRequestBean;
import project.personal.beans.ResponseBean;

@Controller
@RequestMapping("/day-tracker")
public class DayTrackerController {
	
	@RequestMapping(value="/add", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseBean>  addDayTracker(@RequestBody DayTrackerRequestBean requestBean)
	{
		System.out.println("test1");
		DailyTrackerResponseBean dailyTrackerResponseBean = new DailyTrackerResponseBean();
		dailyTrackerResponseBean.setMessage("test");
		ResponseBean responseBean = new ResponseBean(null, "true", null);
		responseBean.setStatus(Boolean.TRUE.toString());
		 return new ResponseEntity<ResponseBean>(responseBean,HttpStatus.OK);
		
	}

}
